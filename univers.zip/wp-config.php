<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'univers' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '?*<K#I%hG&G<aQtMzM(@/[[[>eo0{jePDWN!2Th0SP:;=6TGG:u}H56.%BF/JC|p' );
define( 'SECURE_AUTH_KEY',  ',&ui3jiv$b)V{0Oi9ir%$M*ca|(uzQ]zoGoATiT;3C3U(MH jlD0yq7VjW53U?*_' );
define( 'LOGGED_IN_KEY',    'e?#F.KJ:t@UuFjmQd#ZxZqXGwVICrIrWbvu_/L 9UvC-2Yw@b;n>S*s:evxSZx E' );
define( 'NONCE_KEY',        '8j9zzI&grl[dK46#[RfWUq+ 4Z0:Am*MA<Qd*TZC>#P*YC*W#R~:A6?flJ]1*<~Y' );
define( 'AUTH_SALT',        '*%{Xu_{EZM7w6u8SI/Ynv_7aYkZgk!Sdd_,p|A?GrX/*v6v#;w;F<OgV;)2aMi !' );
define( 'SECURE_AUTH_SALT', '~CiA|5iW,h|X~2K(|uZlZ_p3vm.4b_}5{U}tw86[C.?QiTRMgWKo/ {JrAhTn{BB' );
define( 'LOGGED_IN_SALT',   '-JW!oR[>cR(W<ijpkE%?Hcb[5(%+h -J]H?5<_XU6KH[)`Lpdm2 i@+G(nYPpSqr' );
define( 'NONCE_SALT',       '!`>98#wWP;oJ^DY!b_0?}uL yR8=rU-rR%VO#]2 k5:ipvg}f&na.404N2Y#cL5S' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'ul_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
